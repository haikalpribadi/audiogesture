#ifndef TOPPANEL_H
#define TOPPANEL_H 

#include "Marx2DGraph.h"
#include "MarSystem.h" 
#include "realvec.h"
using namespace MarsyasQt;


class TopPanel : public QWidget
{


public:
  TopPanel(QWidget *parent = 0);
};

	
#endif 
