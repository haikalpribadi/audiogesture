
#include "MarExtractor.h"

using namespace Marsyas;

MarExtractor::MarExtractor()
: AbstractMarExtractor()
{
//to do
}

MarExtractor::~MarExtractor()
{
//to do
}

void
MarExtractor::setup()
{
//to do
}

void
MarExtractor::extract(realvec& dest)
{
//to do
}

