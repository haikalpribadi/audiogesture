
#include "Som.h"

using namespace Marsyas;

Som::Som()
: AbstractMarClusteringModel()
{
   //to do
}

Som::~Som()
{
   //to do
}

void
Som::train(realvec& data)
{
   //to do
}

void
Som::predict(realvec& data)
{
   //to do
}

void
Som::reset()
{
   //to do
}