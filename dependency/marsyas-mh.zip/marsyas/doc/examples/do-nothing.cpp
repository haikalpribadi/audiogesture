#include "MarSystemManager.h"
using namespace Marsyas;

int main(int argc, const char **argv)
{
	MarSystemManager mng;

//	MarSystem* nothingnet = mng.create("Series", "nothingnet");

//	delete nothingnet;
//	exit(0);
}

